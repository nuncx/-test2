#!/bin/bash
echo "Starting RSPS Color Bot..."
python run.py