"""
Detection engine for RSPS Color Bot v3
"""
import time
import logging
import threading
import numpy as np
import cv2
from typing import Dict, List, Tuple, Optional, Any

from ..config import ConfigManager, ColorSpec, ROI
from .capture import CaptureService
from .color_detector import build_mask, build_mask_multi, contours_to_screen_points
from .color_detector import closest_contour_to_point, largest_contour, random_contour

# Get module logger
logger = logging.getLogger('rspsbot.core.detection.detector')

class DetectionEngine:
    """
    Central detection engine that coordinates detection of tiles, monsters, and combat status
    
    This class uses optimizations like regional processing and caching to improve performance.
    """
    
    def __init__(self, config_manager: ConfigManager, capture_service: CaptureService):
        """
        Initialize the detection engine
        
        Args:
            config_manager: Configuration manager
            capture_service: Capture service
        """
        self.config_manager = config_manager
        self.capture_service = capture_service
        
        # Detection components
        self.roi_manager = ROIManager(config_manager, capture_service)
        self.tile_detector = TileDetector(config_manager)
        self.monster_detector = MonsterDetector(config_manager)
        self.combat_detector = CombatDetector(config_manager, capture_service)
        
        # Performance optimizations
        self._cache = {}
        self._cache_lock = threading.RLock()
        self._last_detection_time = 0
        self._last_detection_result = None
        
        # Detection statistics
        self._stats = {
            'tile_detections': 0,
            'monster_detections': 0,
            'combat_detections': 0,
            'detection_time_ms': 0,
            'detection_count': 0
        }
        
        logger.info("Detection engine initialized")
    
    def detect_cycle(self) -> Dict[str, Any]:
        """
        Perform a full detection cycle: ROI > Tiles > Monsters > Combat
        
        Returns:
            Dictionary with detection results
        """
        # Check cache for recent results
        current_time = time.time()
        cache_ttl = self.config_manager.get('detection_cache_ttl', 0.1)
        
        if current_time - self._last_detection_time < cache_ttl:
            return self._last_detection_result.copy()
        
        # Start timing
        start_time = time.time()
        
        # Get active ROI
        roi = self.roi_manager.get_active_roi()
        
        # Early combat check: if configured, skip tile/monster detection while in combat
        in_combat_init = self.combat_detector.is_in_combat()
        hp_seen_init = getattr(self.combat_detector, 'last_hp_seen', False)
        if in_combat_init and self.config_manager.get('skip_detection_when_in_combat', True):
            detection_time_ms = (time.time() - start_time) * 1000
            result = {
                'tiles': [],
                'monsters': [],
                'in_combat': True,
                'hp_seen': hp_seen_init,
                'monsters_by_tile': [],
                'timestamp': current_time,
                'detection_time_ms': detection_time_ms,
                'roi': roi
            }
            self._last_detection_result = result.copy()
            self._last_detection_time = current_time
            return result
        
        # Capture frame for detection
        frame = self.capture_service.capture_region(roi)
        
    # Detect tiles within SEARCH ROI only
        tiles = self.tile_detector.detect_tiles(frame, roi)
        self._stats['tile_detections'] += 1
        
        # If no tiles found, try adaptive search
        if not tiles and self.config_manager.get('adaptive_search', True):
            tiles = self.tile_detector.detect_tiles_adaptive(frame, roi)
        
    # Detect monsters near each tile (still within SEARCH ROI via local ROI windows)
        monsters = []
        monsters_by_tile: List[Tuple[Tuple[int, int], int]] = []
        for tile in tiles:
            tile_monsters = self.monster_detector.detect_monsters_near_tile(frame, roi, tile)
            monsters.extend(tile_monsters)
            monsters_by_tile.append((tile, len(tile_monsters)))
        
        self._stats['monster_detections'] += 1
        
        # Check combat status
        # Determine combat state; CombatDetector captures HP ROI internally
        in_combat = self.combat_detector.is_in_combat()
        hp_seen = getattr(self.combat_detector, 'last_hp_seen', False)
        self._stats['combat_detections'] += 1
        
        # Calculate detection time
        detection_time_ms = (time.time() - start_time) * 1000
        self._stats['detection_time_ms'] += detection_time_ms
        self._stats['detection_count'] += 1
        
        # Create result
        result = {
            'tiles': tiles,
            'monsters': monsters,
            'in_combat': in_combat,
            'hp_seen': hp_seen,
            'monsters_by_tile': monsters_by_tile,
            'timestamp': current_time,
            'detection_time_ms': detection_time_ms,
            'roi': roi
        }
        
        # Cache result
        self._last_detection_result = result.copy()
        self._last_detection_time = current_time
        
        # Log detection stats periodically
        if self._stats['detection_count'] % 100 == 0:
            avg_time = self._stats['detection_time_ms'] / max(1, self._stats['detection_count'])
            logger.debug(f"Detection stats: avg_time={avg_time:.1f}ms, tiles={self._stats['tile_detections']}, monsters={self._stats['monster_detections']}")
        
        return result
    
    def get_stats(self) -> Dict[str, Any]:
        """Get detection statistics"""
        stats = self._stats.copy()
        
        # Calculate averages
        if stats['detection_count'] > 0:
            stats['avg_detection_time_ms'] = stats['detection_time_ms'] / stats['detection_count']
        else:
            stats['avg_detection_time_ms'] = 0
        
        return stats
    
    def reset_stats(self):
        """Reset detection statistics"""
        self._stats = {
            'tile_detections': 0,
            'monster_detections': 0,
            'combat_detections': 0,
            'detection_time_ms': 0,
            'detection_count': 0
        }
    
    def clear_cache(self):
        """Clear detection cache"""
        self._last_detection_time = 0
        self._last_detection_result = None
        self.capture_service.clear_cache()

class ROIManager:
    """
    Manages regions of interest for detection
    """
    
    def __init__(self, config_manager: ConfigManager, capture_service: CaptureService):
        """
        Initialize the ROI manager
        
        Args:
            config_manager: Configuration manager
        """
        self.config_manager = config_manager
        self.capture_service = capture_service
    
    def get_active_roi(self) -> Dict[str, int]:
        """
        Get the active region of interest
        
        Returns:
            Dictionary with left, top, width, height
        """
        # Try to get search ROI from config
        search_roi = self.config_manager.get_roi('search_roi')
        
        if search_roi:
            return search_roi.to_dict()
        
        # Fallback to focused window bbox via capture service
        try:
            bbox = self.capture_service.get_window_bbox()
            return {
                'left': int(bbox['left']),
                'top': int(bbox['top']),
                'width': int(bbox['width']),
                'height': int(bbox['height'])
            }
        except Exception:
            # Last resort safe default
            return {
                'left': 0,
                'top': 0,
                'width': 800,
                'height': 600
            }
    
    def get_detection_bbox(self, base_bbox: Dict[str, int]) -> Dict[str, int]:
        """
        Get detection bbox based on search ROI and base bbox
        
        Args:
            base_bbox: Base bounding box
        
        Returns:
            Detection bounding box
        """
        # If search ROI is set, restrict detection to it
        search_roi = self.config_manager.get_roi('search_roi')
        
        if search_roi:
            wl, wt = base_bbox['left'], base_bbox['top']
            ww, wh = base_bbox['width'], base_bbox['height']
            
            r = search_roi
            l = max(wl, r.left)
            t = max(wt, r.top)
            rgt = min(wl + ww, r.left + r.width)
            btm = min(wt + wh, r.top + r.height)
            
            if rgt > l and btm > t:
                return {
                    'left': l,
                    'top': t,
                    'width': rgt - l,
                    'height': btm - t
                }
        
        return base_bbox

class TileDetector:
    """
    Detects tiles in the game
    """
    
    def __init__(self, config_manager: ConfigManager):
        """
        Initialize the tile detector
        
        Args:
            config_manager: Configuration manager
        """
        self.config_manager = config_manager
    
    def detect_tiles(self, frame: np.ndarray, roi: Dict[str, int]) -> List[Tuple[int, int]]:
        """
        Detect tiles in a frame
        
        Args:
            frame: Input frame
            roi: Region of interest
        
        Returns:
            List of tile center points (x, y)
        """
        # Check if tile detection is enabled
        if not self.config_manager.get('detect_tiles', True):
            return []
        
        # Get tile color and parameters
        tile_color = self.config_manager.get_color_spec('tile_color')
        if not tile_color:
            logger.warning("Tile color not configured")
            return []
        
        search_step = self.config_manager.get('search_step', 2)
        use_precise = self.config_manager.get('use_precise_mode', True)
        tile_min_area = self.config_manager.get('tile_min_area', 30)
        
        try:
            # Build mask and find contours
            _, contours = build_mask(
                frame,
                tile_color,
                search_step,
                use_precise,
                tile_min_area
            )
            
            # Convert contours to screen points
            points = contours_to_screen_points(contours, roi, search_step)
            
            if points:
                logger.debug(f"Detected {len(points)} tiles (step={search_step}, precise={use_precise})")
            else:
                # Try a quick precise fallback at step=1 if nothing found
                if search_step > 1:
                    _, cnt2 = build_mask(
                        frame,
                        tile_color,
                        1,
                        True,
                        max(5, int(tile_min_area * 0.7))
                    )
                    points2 = contours_to_screen_points(cnt2, roi, 1)
                    if points2:
                        logger.debug("Fallback tile detection hit (step=1 precise)")
                        return points2
            
            return points
        
        except Exception as e:
            logger.error(f"Error detecting tiles: {e}")
            return []
    
    def detect_tiles_adaptive(self, frame: np.ndarray, roi: Dict[str, int]) -> List[Tuple[int, int]]:
        """
        Detect tiles with adaptive parameters for difficult cases
        
        Args:
            frame: Input frame
            roi: Region of interest
        
        Returns:
            List of tile center points (x, y)
        """
        # Get tile color
        tile_color_dict = self.config_manager.get('tile_color')
        if not tile_color_dict:
            logger.warning("Tile color not configured")
            return []
        
        # Create a more tolerant color spec
        try:
            tile_color = ColorSpec(
                rgb=tuple(tile_color_dict['rgb']),
                tol_rgb=min(60, int(tile_color_dict.get('tol_rgb', 8)) + 12),
                use_hsv=tile_color_dict.get('use_hsv', True),
                tol_h=min(30, int(tile_color_dict.get('tol_h', 4)) + 6),
                tol_s=min(120, int(tile_color_dict.get('tol_s', 30)) + 25),
                tol_v=min(120, int(tile_color_dict.get('tol_v', 30)) + 25)
            )
            
            # Use step 1 for more precise detection
            search_step = 1
            use_precise = True
            tile_min_area = max(5, int(self.config_manager.get('tile_min_area', 30) * 0.7))
            
            # Build mask and find contours
            _, contours = build_mask(
                frame,
                tile_color,
                search_step,
                use_precise,
                tile_min_area
            )
            
            # Convert contours to screen points
            points = contours_to_screen_points(contours, roi, search_step)
            
            if points:
                logger.debug(f"Adaptive detection found {len(points)} tiles")
            
            return points
        
        except Exception as e:
            logger.error(f"Error in adaptive tile detection: {e}")
            return []

class MonsterDetector:
    """
    Detects monsters in the game
    """
    
    def __init__(self, config_manager: ConfigManager):
        """
        Initialize the monster detector
        
        Args:
            config_manager: Configuration manager
        """
        self.config_manager = config_manager
    
    def detect_monsters_near_tile(
        self,
        frame: np.ndarray,
        base_roi: Dict[str, int],
        tile_center: Tuple[int, int]
    ) -> List[Dict[str, Any]]:
        """
        Detect monsters near a tile
        
        Args:
            frame: Input frame
            base_roi: Base region of interest
            tile_center: Tile center point (x, y)
        
        Returns:
            List of monster dictionaries with position and metadata
        """
        # Check if monster detection is enabled
        if not self.config_manager.get('detect_monsters', True):
            return []
        
        # Create ROI around tile
        roi_bbox = self._create_detection_roi(tile_center, base_roi)
        
        if roi_bbox['width'] <= 0 or roi_bbox['height'] <= 0:
            return []
        
        # Get monster colors
        monster_colors = []
        monster_colors_dicts = self.config_manager.get('monster_colors', [])
        
        for color_dict in monster_colors_dicts:
            try:
                color = ColorSpec(
                    rgb=tuple(color_dict['rgb']),
                    tol_rgb=color_dict.get('tol_rgb', 8),
                    use_hsv=color_dict.get('use_hsv', True),
                    tol_h=color_dict.get('tol_h', 4),
                    tol_s=color_dict.get('tol_s', 30),
                    tol_v=color_dict.get('tol_v', 30)
                )
                monster_colors.append(color)
            except Exception as e:
                logger.error(f"Error creating monster ColorSpec: {e}")
        
        if not monster_colors:
            logger.warning("No valid monster colors configured")
            return []
        
        # Capture ROI
        roi_frame = frame[
            roi_bbox['top'] - base_roi['top']:roi_bbox['top'] - base_roi['top'] + roi_bbox['height'],
            roi_bbox['left'] - base_roi['left']:roi_bbox['left'] - base_roi['left'] + roi_bbox['width']
        ]
        
        # Detection parameters
        step = max(1, self.config_manager.get('monster_scan_step', 1))
        use_precise = self.config_manager.get('use_precise_mode', True)
        monster_min_area = self.config_manager.get('monster_min_area', 15)
        
        # Get additional config for advanced detection
        config_dict = {
            'monster_sat_min': self.config_manager.get('monster_sat_min', 50),
            'monster_val_min': self.config_manager.get('monster_val_min', 50),
            'monster_exclude_tile_color': self.config_manager.get('monster_exclude_tile_color', True),
            'monster_exclude_tile_dilate': self.config_manager.get('monster_exclude_tile_dilate', 1),
            'monster_morph_open_iters': self.config_manager.get('monster_morph_open_iters', 1),
            'monster_morph_close_iters': self.config_manager.get('monster_morph_close_iters', 2),
            'monster_use_lab_assist': self.config_manager.get('monster_use_lab_assist', False),
            'monster_lab_tolerance': self.config_manager.get('monster_lab_tolerance', 20),
            'tile_color': self.config_manager.get('tile_color')
        }
        
        try:
            # Build mask and find contours
            _, contours = build_mask_multi(
                roi_frame,
                monster_colors,
                step,
                use_precise,
                monster_min_area,
                config_dict
            )
            
            # If no contours found, try adaptive detection
            if not contours and self.config_manager.get('adaptive_monster_detection', True):
                contours = self._adaptive_monster_detection(roi_frame, monster_colors, config_dict)
            
            # Convert contours to screen points and create monster objects
            monsters = []
            
            for cnt in contours:
                # Calculate centroid
                M = cv2.moments(cnt)
                
                if M["m00"] == 0:
                    # Fallback to bounding rect center
                    x, y, w, h = cv2.boundingRect(cnt)
                    cx_small, cy_small = x + w // 2, y + h // 2
                else:
                    # Use centroid
                    cx_small = int(M["m10"] / M["m00"])
                    cy_small = int(M["m01"] / M["m00"])
                
                # Convert to screen coordinates
                screen_x = roi_bbox['left'] + cx_small * step
                screen_y = roi_bbox['top'] + cy_small * step
                
                # Calculate area and size
                area = cv2.contourArea(cnt)
                x, y, w, h = cv2.boundingRect(cnt)
                
                # Create monster object
                monster = {
                    'position': (screen_x, screen_y),
                    'area': area * step * step,
                    'width': w * step,
                    'height': h * step,
                    'tile_center': tile_center,
                    'distance': ((screen_x - tile_center[0]) ** 2 + (screen_y - tile_center[1]) ** 2) ** 0.5
                }
                
                monsters.append(monster)
            
            if monsters:
                logger.debug(f"Detected {len(monsters)} monsters near tile {tile_center}")
            
            return monsters
        
        except Exception as e:
            logger.error(f"Error detecting monsters: {e}")
            return []
    
    def _create_detection_roi(
        self,
        center: Tuple[int, int],
        base_roi: Dict[str, int]
    ) -> Dict[str, int]:
        """
        Create a region of interest around a center point
        
        Args:
            center: Center point (x, y)
            base_roi: Base region of interest
        
        Returns:
            ROI dictionary
        """
        cx, cy = center
        radius = self.config_manager.get('around_tile_radius', 120)
        
        left = base_roi['left']
        top = base_roi['top']
        width = base_roi['width']
        height = base_roi['height']
        
        # Calculate ROI bounds
        x0 = max(left, cx - radius)
        y0 = max(top, cy - radius)
        x1 = min(left + width, cx + radius)
        y1 = min(top + height, cy + radius)
        
        return {
            'left': x0,
            'top': y0,
            'width': max(0, x1 - x0),
            'height': max(0, y1 - y0)
        }
    
    def _adaptive_monster_detection(
        self,
        frame: np.ndarray,
        monster_colors: List[ColorSpec],
        config_dict: Dict
    ) -> List:
        """
        Adaptive monster detection with more tolerant parameters
        
        Args:
            frame: Input frame
            monster_colors: List of monster color specs
            config_dict: Configuration dictionary
        
        Returns:
            List of contours
        """
        # Create more tolerant color specs
        adaptive_colors = []
        
        for spec in monster_colors:
            adaptive_spec = ColorSpec(
                rgb=spec.rgb,
                tol_rgb=min(60, spec.tol_rgb + 12),
                use_hsv=spec.use_hsv,
                tol_h=min(30, spec.tol_h + 6),
                tol_s=min(120, spec.tol_s + 25),
                tol_v=min(120, spec.tol_v + 25)
            )
            adaptive_colors.append(adaptive_spec)
        
        # Use step 1 for more precise detection
        step = 1
        use_precise = True
        monster_min_area = max(5, int(self.config_manager.get('monster_min_area', 15) * 0.7))
        
        # Build mask and find contours
        _, contours = build_mask_multi(
            frame,
            adaptive_colors,
            step,
            use_precise,
            monster_min_area,
            config_dict
        )
        
        if contours:
            logger.debug(f"Adaptive detection found {len(contours)} monsters")
        
        return contours

class CombatDetector:
    """
    Detects combat status based on HP bar
    """
    
    def __init__(self, config_manager: ConfigManager, capture_service: CaptureService):
        """
        Initialize the combat detector
        
        Args:
            config_manager: Configuration manager
            capture_service: Capture service for grabbing HP ROI
        """
        self.config_manager = config_manager
        self.capture_service = capture_service
        
        # Combat state tracking
        self.in_combat = False
        self.last_combat_time = 0.0
        # Use configured timeout key with sensible fallback
        self.combat_timeout = float(
            self.config_manager.get('combat_not_seen_timeout_s', self.config_manager.get('combat_timeout', 10.0))
        )
        self.leave_immediately = bool(self.config_manager.get('combat_leave_immediately', True))
    
    def is_in_combat(self) -> bool:
        """
        Detect if player is in combat based on HP bar
        
        Returns:
            True if in combat, False otherwise
        """
        # Check if HP bar detection is enabled
        if not self.config_manager.get('hpbar_detect_enabled', True):
            return False
        
        # Get HP bar ROI
        hp_roi = self.config_manager.get_roi('hpbar_roi')
        if not hp_roi:
            return False
        
        # Detect HP bar in current screen
        hp_detected = self._detect_hp_bar(hp_roi)
        
        # Update combat state
        current_time = time.time()
        if hp_detected:
            self.last_hp_seen = True
            if not self.in_combat:
                logger.debug("HP bar detected -> entering combat")
            self.in_combat = True
            self.last_combat_time = current_time
        else:
            self.last_hp_seen = False
            if self.in_combat:
                if self.leave_immediately:
                    logger.debug("HP bar not seen -> leaving combat immediately")
                    self.in_combat = False
                elif (current_time - self.last_combat_time > self.combat_timeout):
                    logger.debug("HP bar not seen for timeout -> leaving combat")
                    self.in_combat = False
        
        return self.in_combat
    
    def _detect_hp_bar(self, hp_roi: ROI) -> bool:
        """
        Detect HP bar in the configured ROI using color thresholding
        
        Returns:
            True if HP bar detected, False otherwise
        """
        try:
            # Get color spec and thresholds
            color_spec = self.config_manager.get_color_spec('hpbar_color')
            if not color_spec:
                logger.warning("HP bar color not configured")
                return False
            min_area = int(self.config_manager.get('hpbar_min_area', 50))
            min_pixels = int(self.config_manager.get('hpbar_min_pixel_matches', 150))
            
            # Capture region
            frame = self.capture_service.capture_region(hp_roi)
            mask, contours = build_mask(frame, color_spec, step=1, precise=True, min_area=min_area)
            
            # Quick pixel threshold test
            pixel_matches = int((mask > 0).sum())
            if pixel_matches < min_pixels:
                return False
            
            # If any contour passes area threshold we consider it detected
            detected = len(contours) > 0
            return detected
        except Exception as e:
            logger.error(f"Error detecting HP bar: {e}")
            return False