"""
GUI components for RSPS Color Bot v3
"""
from .main_window import MainWindow
from .visualization.debug_overlay import DebugOverlayWindow